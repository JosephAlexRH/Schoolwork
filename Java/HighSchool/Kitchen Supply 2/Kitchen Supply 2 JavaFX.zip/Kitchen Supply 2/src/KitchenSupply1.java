import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class KitchenSupply1 extends JFrame {
    private JPanel MainPanel;
    private JList ListJList;
    private JTextField ProductNameTextField;
    private JTextField QuantityJTextField;
    private JTextField ExpirationDateJTextField;
    private JButton createNewButton;
    private JButton saveButton;
    private JLabel ResultLabel;
    private JButton LoadButton;
    private JButton writeButton;
    private JButton clearButton;
    private JPanel JPanelRight;
    private JLabel ProductName;
    private JLabel QuantityLabel;
    private JLabel ExpirationDateJLabel;
    private JPanel ResultsJPanel;
    private JLabel ExpirationResultLabel;
    private JPanel ButtonsJPanel;
    private JPanel ButtonsPanel2;
    private JPanel JPanelLeft;
    private ArrayList<Food> Foods;
    private DefaultListModel FoodListModel;

    public KitchenSupply1(String title) throws IOException {
        super(title);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(MainPanel);
        this.pack();
        Foods = new ArrayList<Food>();

        FoodListModel = new DefaultListModel();
        ListJList.setModel(FoodListModel);
        createNewButton.setEnabled(false);
        createNewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int FoodNum = ListJList.getSelectedIndex();

                if (FoodNum >= 0) {
                    Food f = Foods.get(FoodNum);
                    f.setName(ProductNameTextField.getText());
                    f.setQuantity(QuantityJTextField.getText());
                    f.setExpirationDate(ExpirationDateJTextField.getText());
                    UpdateFood();
                }

            }
        });
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Food f = new Food(ProductNameTextField.getText(), QuantityJTextField.getText(), ExpirationDateJTextField.getText());
                Foods.add(f);
                UpdateFood();
            }
        });
        ListJList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int numOfFood = ListJList.getSelectedIndex();
                if (numOfFood >= 0) {
                    Food f = Foods.get(numOfFood);
                    ProductNameTextField.setText(f.getName());
                    QuantityJTextField.setText(f.getQuantity());
                    ExpirationDateJTextField.setText(f.getExpirationDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    ResultLabel.setText(Integer.toString(f.getDaysLeft()) + " days");
                    createNewButton.setEnabled(true);
                } else {
                    createNewButton.setEnabled(false);
                }
            }
        });
        writeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int val = ListJList.getModel().getSize();
                PrintWriter writer = null;
                try {
                    writer = new PrintWriter("data.txt");
                    writer.println(val);
                    for (int i = 0; i < val; i++) {
                        writer.println(Foods.get(i).getName() + "," + Foods.get(i).getQuantity() + "," + Foods.get(i).getExpirationDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    }
                } catch (Exception a) {
                    System.out.println(" " + a);
                } finally {
                    writer.close();
                }
            }
        });
        LoadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BufferedReader br = null;
                try {
                    br = new BufferedReader(new FileReader("data.txt"));
                    int val = Integer.parseInt(br.readLine());
                    for (int i = 0; i < val; i++) {
                        String Temp = br.readLine();
                        String[] arrTemp = Temp.split(",");
                        Food temp = new Food(arrTemp[0], arrTemp[1], arrTemp[2]);
                        Foods.add(temp);
                    }
                } catch (Exception a) {
                    System.out.println("" + a);
                }
                UpdateFood();
            }
        });
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PrintWriter writer = null;
                try {
                    writer = new PrintWriter("data.txt");
                } catch (FileNotFoundException fileNotFoundException) {
                    fileNotFoundException.printStackTrace();
                }
                writer.print("");
                writer.close();
                UpdateFood();
            }
        });

    }


    public void UpdateFood() {
        FoodListModel.removeAllElements();
        for (Food f : Foods) {
            FoodListModel.addElement(f.getName());
        }

    }

    public void addFood(Food food) {
        Foods.add(food);
        UpdateFood();
    }


    public static void main(String[] args) throws IOException {
        KitchenSupply1 frame = new KitchenSupply1("Kitchen Supply");
        frame.setVisible(true);

    }

}
